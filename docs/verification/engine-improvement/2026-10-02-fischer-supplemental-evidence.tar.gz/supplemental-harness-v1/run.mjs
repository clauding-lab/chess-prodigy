// Evidence-only supplemental diagnostic schedule. Never imported by product code.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import os from 'node:os';import {pathToFileURL} from 'node:url';
const root=process.cwd(),base=path.join(root,'.superpowers/sdd/2026-09-27-repair-and-engine-master-plan'),out=path.join(base,'fischer-supplemental-v1');
const hash=v=>crypto.createHash('sha256').update(v).digest('hex'),read=p=>fs.readFileSync(p),json=p=>JSON.parse(read(p));
if(fs.existsSync(out))throw Error('Existing diagnostic output: automatic restart prohibited');
const reference=json(path.join(base,'reference-feasibility-v1/summary.json'));
if(reference.total!==24||reference.complete!==24)throw Error('Development reference feasibility not complete');
const original=path.join(base,'strength-development-v1/fischer-casual'),manifest=json(path.join(original,'manifest.json'));
const machine={node:process.version,arch:os.arch(),platform:os.platform(),cpu:os.cpus()[0].model,cpuCount:os.cpus().length};
if(JSON.stringify(machine)!==JSON.stringify(manifest.machine))throw Error('Original machine/Node mismatch');
const {strengthSeed}=await import(pathToFileURL(path.join(root,'scripts/engine-bench/strength-core.ts')));
const {playStrengthGame,verifyStrengthGame}=await import(pathToFileURL(path.join(root,'scripts/engine-bench/strength-match.ts')));
const {workerChooser}=await import(pathToFileURL(path.join(root,'scripts/engine-bench/strength-worker.ts')));
const priorSeeds=new Set();
for(const scope of ['tal-casual','tal-club','tal-strong','fischer-casual','fischer-club','fischer-strong'])for(const row of json(path.join(base,'strength-development-v1',scope,'manifest.json')).schedule){priorSeeds.add(row.seed);priorSeeds.add(row.baselineSeed);}
const unique=new Set(),schedule=[];
for(let pair=0;pair<2;pair++){
 const label=`fischer-diagnostic-v1:development:casual:${pair}`,seed=strengthSeed(label),baselineSeed=strengthSeed(label+':baseline:fischer');
 for(const s of [seed,baselineSeed]){if(priorSeeds.has(s)||unique.has(s))throw Error('Seed collision; no reseeding allowed');unique.add(s);}
 for(const color of ['w','b'])schedule.push({key:`diagnostic-fischer-casual-${pair}-${color}`,candidate:'fischer',baseline:'fischer',level:'casual',pair,color,seed,baselineSeed});
}
const bundles={};
for(const name of ['experiment','tal','fischer']){const contents=read(path.join(original,name+'.cjs'));if(hash(contents)!==manifest.bundles[name])throw Error('Original worker bundle mismatch');bundles[name]=contents.toString('utf8');}
const files=p=>fs.readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(p,e.name)):[path.join(p,e.name)]);
const protocol='docs/superpowers/specs/2026-10-02-fischer-supplemental-diagnostics.md';
const source=()=>Object.fromEntries([...files('src'),...files('scripts/engine-bench'),'scripts/calibration/core.ts','package.json','package-lock.json',protocol].sort().map(p=>[p,hash(read(p))]));
const frozenSource=source(),sameSource=()=>JSON.stringify(source())===JSON.stringify(frozenSource);
fs.mkdirSync(out);const write=(name,v)=>fs.writeFileSync(path.join(out,name),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
write('manifest.json',{purpose:'supplemental-diagnostic-only',qualification:false,originalFailure:'fischer-casual-0-w remains unresolved; not replaced',machine,source:frozenSource,runnerHash:hash(read(new URL(import.meta.url))),bundles:manifest.bundles,settings:{...manifest.settings,failureEvidenceVersion:1},schedule,referenceSummaryHash:hash(read(path.join(base,'reference-feasibility-v1/summary.json')))});
for(const [name,contents] of Object.entries(bundles))fs.writeFileSync(path.join(out,name+'.cjs'),contents,{flag:'wx'});
let completed=0,stopped=null;
for(const row of schedule){
 if(!sameSource())throw Error('Source drift before game');
 write(row.key+'.started.json',{row,startedAt:new Date().toISOString()});
 let game=null,verified=false,error=null;
 try {game=await playStrengthGame(row,workerChooser(row,bundles));verifyStrengthGame(game,row);if(!sameSource())throw Error('Source drift during game');verified=true;}
 catch(e){error=String(e);}
 write(row.key+'.json',{purpose:'supplemental-diagnostic-only',qualification:false,game,verified,error});
 console.log(JSON.stringify({key:row.key,verified,error,reason:game?.reason,plies:game?.moves.length,elapsedMs:game?.elapsedMs}));
 if(!verified||game?.score===null){stopped={key:row.key,reason:error??game?.failure??game?.reason};break;}
 completed++;
}
write('status.json',{purpose:'supplemental-diagnostic-only',qualification:false,scheduled:4,completed,stopped,statement:'Original failure remains unresolved. These games do not establish reliability or playing strength.'});
