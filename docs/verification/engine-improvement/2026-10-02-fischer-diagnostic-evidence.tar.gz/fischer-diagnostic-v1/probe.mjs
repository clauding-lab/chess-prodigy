// Throwaway diagnostic harness. Never imported by the application or strength runner.
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';
import os from 'node:os';
import {Worker} from 'node:worker_threads';
import {build} from 'esbuild';
const root=process.cwd(),base=path.join(root,'.superpowers/sdd/2026-09-27-repair-and-engine-master-plan');
const frozen=path.join(base,'frozen-source-521fef2'),out=path.join(base,'fischer-diagnostic-v1');
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const read=p=>fs.readFileSync(p,'utf8');
const json=p=>JSON.parse(read(p));
const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const original=path.join(base,'strength-development-v1/fischer-casual');
const manifest=json(path.join(original,'manifest.json'));
for(const [file,digest] of Object.entries(manifest.source))if(hash(fs.readFileSync(path.join(frozen,file)))!==digest)throw Error('Frozen source mismatch '+file);
if(process.version!==manifest.machine.node)throw Error('Wrong Node');
const {START,applyMove,legalMoves,sanFor,toFEN}=await import(pathToFileURL(path.join(frozen,'src/engine/board.ts')));
const dataset=path.join(root,'docs/verification/engine-improvement/e0-dataset-v1');
const raw=read(path.join(dataset,'development.json')),dm=json(path.join(dataset,'manifest.json'));
const cohort=json(path.join(root,'docs/verification/engine-improvement/e0-development12-production-isolated-v1/run-manifest.json'));
if(hash(raw)!==dm.partitions.development || hash(raw)!==cohort.developmentHash || hash(JSON.stringify(dm))!==cohort.datasetManifestHash)throw Error('Dataset drift');
if(cohort.samples.length!==12 || new Set(cohort.samples).size!==12)throw Error('Cohort mismatch');
const all=JSON.parse(raw);
const selected=cohort.samples.map(id=>{const s=all.find(s=>s.id===id&&s.split==='development');if(!s)throw Error('Missing sample');return {...s,seed:317};});
const failed=json(path.join(original,'fischer-casual-0-w.json'));
if(hash(read(path.join(original,'fischer-casual-0-w.json')))!=='ecfdf2690a15bd15516c00c3f43fa036e3a0c8924208f6da76acafa3a10917fd')throw Error('Failure drift');
selected.push({id:'failed-position-only',history:failed.moves,fen:failed.fen,seed:failed.row.seed});
const inputs=selected.map(sample=>{
 let position=START();const history=[];
 for(const san of sample.history){history.push(toFEN(position));const m=legalMoves(position).find(m=>sanFor(position,m,applyMove(position,m))===san);if(!m)throw Error('Illegal history');position=applyMove(position,m);}
 if(toFEN(position)!==sample.fen)throw Error('FEN mismatch');
 return {id:sample.id,position,history,fen:sample.fen,opponent:{id:'fischer',version:2,engine:'fischer-coherent-v1',randomPolicy:'seeded-per-ply-v1',seed:sample.seed},level:'casual',turnDeadline:null};
});
const source=read(path.join(frozen,'src/engine/next/shortlist-reuse-search.ts'));
function replaceOnce(text,needle,replacement){if(text.split(needle).length!==2)throw Error('Instrumentation anchor not unique');return text.replace(needle,replacement);}
let instrumented=replaceOnce(source,'  const clock = options.now',`  const metric = {entry:performance.now(), historyLength:history.length, ms:options.ms, baselineOnly:options.baselineOnly===true};
  globalThis.__probe.push(metric);
  const clock = options.now`);
instrumented=replaceOnce(instrumented,'  const evidence = (): Evidence => ({',`  metric.prepared=performance.now();
  const evidence = (): Evidence => ({`);
instrumented=replaceOnce(instrumented,'    iteration(2, "baseline");',`    metric.baselineStart=performance.now();
    iteration(2, "baseline");
    metric.baselineEnd=performance.now();`);
instrumented=replaceOnce(instrumented,'  return completed\n',`  metric.returned=performance.now();
  return completed\n`);
const plugin={name:'diagnostic-copy',setup(b){b.onLoad({filter:/shortlist-reuse-search\.ts$/},()=>({contents:instrumented,loader:'ts',resolveDir:path.join(frozen,'src/engine/next')}));}};
const full=(await build({entryPoints:[path.join(frozen,'src/worker/next/experiment.worker.ts')],bundle:true,write:false,format:'cjs',platform:'browser',plugins:[plugin]})).outputFiles[0].text;
const fixed=(await build({stdin:{contents:`import {searchNextShortlistReuse} from './src/engine/next/shortlist-reuse-search';self.onmessage=({data:r})=>self.postMessage({ok:true,requestId:r.requestId,gameId:r.gameId,revision:r.revision,result:searchNextShortlistReuse(r.position,r.history,{maxDepth:2,ms:1,now:()=>0,maxNodes:1000000,baselineOnly:true})});`,resolveDir:frozen},bundle:true,write:false,format:'cjs',platform:'browser',plugins:[plugin]})).outputFiles[0].text;
for(const [name,contents] of Object.entries({full,fixed,instrumented}))fs.writeFileSync(path.join(out,name+(name==='instrumented'?'.ts':'.cjs')),contents,{flag:'wx'});
const schedule=inputs.flatMap((input,index)=>['full','fixed'].map(mode=>({key:`${String(index+1).padStart(2,'0')}-${mode}`,mode,input})));
write('manifest.json',{purpose:'diagnostic-only-not-a-match',node:process.version,machine:{cpu:os.cpus()[0].model,cpuCount:os.cpus().length,arch:os.arch(),platform:os.platform()},source:manifest.source,datasetHash:hash(raw),probeHash:hash(read(new URL(import.meta.url))),instrumentedHash:hash(instrumented),bundles:{full:hash(full),fixed:hash(fixed)},schedule,capacityMs:15000,protocolHash:hash(read('docs/superpowers/specs/2026-10-02-fischer-diagnostic-probe.md'))});
for(const row of schedule){
 write(row.key+'.started.json',{key:row.key,startedAt:new Date().toISOString()});
 const request={...row.input,gameId:row.key,revision:row.input.history.length,requestId:1};
 const start=performance.now();let ready=null,replyAt=null;
 const worker=new Worker(`const {parentPort}=require('node:worker_threads');globalThis.__probe=[];globalThis.self={postMessage(reply){parentPort.postMessage({reply,metrics:globalThis.__probe})}};${row.mode==='full'?full:fixed}\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({ready:true});`,{eval:true});
 let record,response=null;
 try {
  response=await new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>reject(Error('diagnostic capacity exceeded')),15000);
   const settle=(fn,v)=>{clearTimeout(timer);fn(v);};
   worker.once('error',e=>settle(reject,e));worker.once('exit',code=>settle(reject,Error('worker exited '+code)));
   worker.on('message',m=>{if(m.ready&&ready===null){ready=performance.now();worker.postMessage(request);}else if(Object.hasOwn(m,'reply')){replyAt=performance.now();settle(resolve,m);}});
  });
  const r=response.reply;
  if(r?.ok===false)throw Error('Worker reported calculation failure');
  if(r?.ok!==true||r.gameId!==request.gameId||r.requestId!==1||r.revision!==request.revision)throw Error('Reply identity mismatch');
  if(r.result.move&&!legalMoves(row.input.position).some(m=>JSON.stringify(m)===JSON.stringify(r.result.move)))throw Error('Illegal result move');
  record={...row,request,response,startupMs:ready-start,calculationMs:replyAt-ready,elapsedMs:replyAt-start};
 } catch(e){record={...row,request,response,error:String(e),startupMs:ready===null?null:ready-start,calculationMs:ready===null?null:(replyAt??performance.now())-ready,elapsedMs:performance.now()-start};}
 finally {await worker.terminate();}
 write(row.key+'.json',record);
 console.log(JSON.stringify({key:row.key,id:row.input.id,kind:record.response?.reply?.result?.kind,error:record.error}));
}
