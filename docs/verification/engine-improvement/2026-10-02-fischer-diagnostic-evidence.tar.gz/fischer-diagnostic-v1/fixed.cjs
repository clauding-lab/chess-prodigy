// .superpowers/sdd/2026-09-27-repair-and-engine-master-plan/frozen-source-521fef2/src/engine/board.ts
var idx = (row, col) => row * 8 + col;
var rowOf = (square) => Math.floor(square / 8);
var colOf = (square) => square % 8;
var inB = (row, col) => row >= 0 && row < 8 && col >= 0 && col < 8;
var FILES = "abcdefgh";
var sqName = (square) => `${FILES[colOf(square)]}${8 - rowOf(square)}`;
var sqIndex = (name) => {
  if (!/^[a-h][1-8]$/.test(name)) throw new Error(`Invalid square: ${name}`);
  return idx(8 - Number(name[1]), FILES.indexOf(name[0]));
};
var KN = [
  [-2, -1],
  [-2, 1],
  [-1, -2],
  [-1, 2],
  [1, -2],
  [1, 2],
  [2, -1],
  [2, 1]
];
var KG = [
  [-1, -1],
  [-1, 0],
  [-1, 1],
  [0, -1],
  [0, 1],
  [1, -1],
  [1, 0],
  [1, 1]
];
var DIAG = [
  [-1, -1],
  [-1, 1],
  [1, -1],
  [1, 1]
];
var ORTH = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1]
];
var opposite = (color) => color === "w" ? "b" : "w";
var kind = (piece) => piece[1];
function isAttacked(board, row, col, by) {
  const pawnRow = by === "w" ? row + 1 : row - 1;
  for (const dc of [-1, 1])
    if (inB(pawnRow, col + dc) && board[idx(pawnRow, col + dc)] === `${by}p`) return true;
  for (const [dr, dc] of KN)
    if (inB(row + dr, col + dc) && board[idx(row + dr, col + dc)] === `${by}n`) return true;
  for (const [dr, dc] of KG)
    if (inB(row + dr, col + dc) && board[idx(row + dr, col + dc)] === `${by}k`) return true;
  for (const [dr, dc] of ORTH) {
    let r = row + dr, c = col + dc;
    while (inB(r, c)) {
      const piece = board[idx(r, c)];
      if (piece) {
        if (piece[0] === by && (kind(piece) === "r" || kind(piece) === "q")) return true;
        break;
      }
      r += dr;
      c += dc;
    }
  }
  for (const [dr, dc] of DIAG) {
    let r = row + dr, c = col + dc;
    while (inB(r, c)) {
      const piece = board[idx(r, c)];
      if (piece) {
        if (piece[0] === by && (kind(piece) === "b" || kind(piece) === "q")) return true;
        break;
      }
      r += dr;
      c += dc;
    }
  }
  return false;
}
function kingSq(board, color) {
  return board.indexOf(`${color}k`);
}
function inCheck(position, color) {
  const square = kingSq(position.board, color);
  return square >= 0 && isAttacked(position.board, rowOf(square), colOf(square), opposite(color));
}
function genPseudo(position) {
  const { board, turn, castling, ep } = position;
  const moves = [], enemy = opposite(turn);
  for (let from = 0; from < 64; from++) {
    const piece = board[from];
    if (!piece || piece[0] !== turn) continue;
    const row = rowOf(from), col = colOf(from), type = kind(piece);
    if (type === "p") {
      const dir = turn === "w" ? -1 : 1, startRow = turn === "w" ? 6 : 1, promotionRow = turn === "w" ? 0 : 7;
      const nextRow = row + dir;
      if (inB(nextRow, col)) {
        const one = idx(nextRow, col);
        if (!board[one]) {
          if (nextRow === promotionRow)
            for (const promo of ["q", "r", "b", "n"]) moves.push({ from, to: one, promo });
          else {
            moves.push({ from, to: one });
            const two = idx(row + 2 * dir, col);
            if (row === startRow && !board[two]) moves.push({ from, to: two, double: true });
          }
        }
      }
      for (const dc of [-1, 1]) {
        if (!inB(nextRow, col + dc)) continue;
        const to = idx(nextRow, col + dc), target = board[to];
        if (target && target[0] === enemy) {
          if (nextRow === promotionRow)
            for (const promo of ["q", "r", "b", "n"])
              moves.push({ from, to, promo, capture: target });
          else moves.push({ from, to, capture: target });
        } else if (to === ep) moves.push({ from, to, ep: true, capture: `${enemy}p` });
      }
    } else if (type === "n" || type === "k") {
      for (const [dr, dc] of type === "n" ? KN : KG) {
        if (!inB(row + dr, col + dc)) continue;
        const to = idx(row + dr, col + dc), target = board[to];
        if (!target) moves.push({ from, to });
        else if (target[0] === enemy) moves.push({ from, to, capture: target });
      }
      if (type === "k") {
        const home = turn === "w" ? 7 : 0;
        const kingside = turn === "w" ? "K" : "k", queenside = turn === "w" ? "Q" : "q";
        if (row === home && col === 4 && !isAttacked(board, home, 4, enemy)) {
          if (castling[kingside] && !board[idx(home, 5)] && !board[idx(home, 6)] && board[idx(home, 7)] === `${turn}r` && !isAttacked(board, home, 5, enemy) && !isAttacked(board, home, 6, enemy))
            moves.push({ from, to: idx(home, 6), castle: "K" });
          if (castling[queenside] && !board[idx(home, 3)] && !board[idx(home, 2)] && !board[idx(home, 1)] && board[idx(home, 0)] === `${turn}r` && !isAttacked(board, home, 3, enemy) && !isAttacked(board, home, 2, enemy))
            moves.push({ from, to: idx(home, 2), castle: "Q" });
        }
      }
    } else {
      const directions = type === "b" ? DIAG : type === "r" ? ORTH : [...DIAG, ...ORTH];
      for (const [dr, dc] of directions) {
        let r = row + dr, c = col + dc;
        while (inB(r, c)) {
          const to = idx(r, c), target = board[to];
          if (!target) moves.push({ from, to });
          else {
            if (target[0] === enemy) moves.push({ from, to, capture: target });
            break;
          }
          r += dr;
          c += dc;
        }
      }
    }
  }
  return moves;
}
function applyMove(position, move) {
  const board = position.board.slice(), piece = board[move.from];
  if (!piece || piece[0] !== position.turn) throw new Error("Move has no moving piece");
  const turn = position.turn, enemy = opposite(turn), fromRow = rowOf(move.from), fromCol = colOf(move.from), toRow = rowOf(move.to), toCol = colOf(move.to);
  board[move.to] = move.promo ? `${turn}${move.promo}` : piece;
  board[move.from] = null;
  if (move.ep) board[idx(fromRow, toCol)] = null;
  if (move.castle === "K") {
    board[idx(fromRow, 5)] = board[idx(fromRow, 7)];
    board[idx(fromRow, 7)] = null;
  }
  if (move.castle === "Q") {
    board[idx(fromRow, 3)] = board[idx(fromRow, 0)];
    board[idx(fromRow, 0)] = null;
  }
  const castling = { ...position.castling };
  if (piece === "wk") {
    castling.K = false;
    castling.Q = false;
  }
  if (piece === "bk") {
    castling.k = false;
    castling.q = false;
  }
  if (move.from === 63 || move.to === 63) castling.K = false;
  if (move.from === 56 || move.to === 56) castling.Q = false;
  if (move.from === 7 || move.to === 7) castling.k = false;
  if (move.from === 0 || move.to === 0) castling.q = false;
  return {
    board,
    turn: enemy,
    castling,
    ep: move.double ? idx((fromRow + toRow) / 2, fromCol) : null,
    halfmove: kind(piece) === "p" || move.capture ? 0 : position.halfmove + 1,
    fullmove: turn === "b" ? position.fullmove + 1 : position.fullmove
  };
}
function legalFilter(position, moves) {
  const enemy = opposite(position.turn), initialKing = kingSq(position.board, position.turn);
  return moves.filter((move) => {
    const next = applyMove(position, move);
    const moving = position.board[move.from];
    const king = moving && kind(moving) === "k" ? move.to : initialKing;
    return king >= 0 && !isAttacked(next.board, rowOf(king), colOf(king), enemy);
  });
}
var legalMoves = (position) => legalFilter(position, genPseudo(position));
function posKey(position) {
  const c = position.castling;
  const legalEp = position.ep !== null && legalFilter(
    position,
    genPseudo(position).filter((move) => move.ep)
  ).length > 0;
  return position.board.map((piece) => piece ?? ".").join("") + position.turn + (c.K ? "K" : "") + (c.Q ? "Q" : "") + (c.k ? "k" : "") + (c.q ? "q" : "") + (legalEp ? sqName(position.ep) : "-");
}
function toFEN(position) {
  const ranks = [];
  for (let row = 0; row < 8; row++) {
    let rank = "", empty = 0;
    for (let col = 0; col < 8; col++) {
      const piece = position.board[idx(row, col)];
      if (!piece) empty++;
      else {
        if (empty) {
          rank += empty;
          empty = 0;
        }
        rank += piece[0] === "w" ? kind(piece).toUpperCase() : kind(piece);
      }
    }
    if (empty) rank += empty;
    ranks.push(rank);
  }
  const rights = (position.castling.K ? "K" : "") + (position.castling.Q ? "Q" : "") + (position.castling.k ? "k" : "") + (position.castling.q ? "q" : "");
  return `${ranks.join("/")} ${position.turn} ${rights || "-"} ${position.ep === null ? "-" : sqName(position.ep)} ${position.halfmove} ${position.fullmove}`;
}
function fromFEN(fen) {
  const fields = fen.trim().split(/\s+/);
  if (fields.length !== 6) throw new Error("FEN must contain six fields");
  const [placement, turnText, rightsText, epText, halfText, fullText] = fields;
  if (turnText !== "w" && turnText !== "b") throw new Error("Invalid active colour");
  const ranks = placement.split("/");
  if (ranks.length !== 8) throw new Error("FEN must contain eight ranks");
  const board = [];
  for (const rank of ranks) {
    let count = 0;
    for (const symbol of rank) {
      if (/^[1-8]$/.test(symbol)) {
        const empty = Number(symbol);
        board.push(...new Array(empty).fill(null));
        count += empty;
      } else if (/^[prnbqkPRNBQK]$/.test(symbol)) {
        board.push(
          `${symbol === symbol.toUpperCase() ? "w" : "b"}${symbol.toLowerCase()}`
        );
        count++;
      } else throw new Error("Unknown FEN piece");
    }
    if (count !== 8) throw new Error("Each rank must contain eight squares");
  }
  if (board.filter((p) => p === "wk").length !== 1 || board.filter((p) => p === "bk").length !== 1)
    throw new Error("Position must have one king per colour");
  const whiteKing = kingSq(board, "w"), blackKing = kingSq(board, "b");
  if (Math.abs(rowOf(whiteKing) - rowOf(blackKing)) <= 1 && Math.abs(colOf(whiteKing) - colOf(blackKing)) <= 1)
    throw new Error("Kings cannot be adjacent");
  if (board.slice(0, 8).concat(board.slice(56)).some((p) => p?.[1] === "p"))
    throw new Error("Pawn on terminal rank");
  if (rightsText !== "-" && (!/^[KQkq]+$/.test(rightsText) || new Set(rightsText).size !== rightsText.length))
    throw new Error("Invalid castling rights");
  const castling = {
    K: rightsText.includes("K"),
    Q: rightsText.includes("Q"),
    k: rightsText.includes("k"),
    q: rightsText.includes("q")
  };
  if (castling.K && (board[60] !== "wk" || board[63] !== "wr") || castling.Q && (board[60] !== "wk" || board[56] !== "wr") || castling.k && (board[4] !== "bk" || board[7] !== "br") || castling.q && (board[4] !== "bk" || board[0] !== "br"))
    throw new Error("Castling pieces are inconsistent");
  let ep = null;
  if (epText !== "-") {
    if (!/^[a-h][36]$/.test(epText)) throw new Error("Invalid en-passant square");
    ep = sqIndex(epText);
    const expectedRank = turnText === "w" ? "6" : "3";
    if (epText[1] !== expectedRank) throw new Error("En-passant rank contradicts active colour");
    const pawnSquare = ep + (turnText === "w" ? 8 : -8);
    if (board[ep] !== null || board[pawnSquare] !== `${opposite(turnText)}p`)
      throw new Error("Impossible en-passant structure");
  }
  if (!/^\d+$/.test(halfText) || !/^\d+$/.test(fullText)) throw new Error("Invalid move counters");
  const halfmove = Number(halfText), fullmove = Number(fullText);
  if (!Number.isSafeInteger(halfmove) || !Number.isSafeInteger(fullmove) || fullmove < 1)
    throw new Error("Invalid move counters");
  return { board, turn: turnText, castling, ep, halfmove, fullmove };
}
function insufficientMaterial(board) {
  const minors = [];
  for (let square = 0; square < 64; square++) {
    const piece = board[square];
    if (!piece || kind(piece) === "k") continue;
    if (kind(piece) === "b" || kind(piece) === "n") minors.push({ piece, square });
    else return false;
  }
  if (minors.length <= 1) return true;
  return minors.length === 2 && minors.every(({ piece }) => kind(piece) === "b") && minors[0].piece[0] !== minors[1].piece[0] && (rowOf(minors[0].square) + colOf(minors[0].square)) % 2 === (rowOf(minors[1].square) + colOf(minors[1].square)) % 2;
}
function sameMove(a, b) {
  return Boolean(
    a && b && a.from === b.from && a.to === b.to && (a.promo ?? null) === (b.promo ?? null)
  );
}

// .superpowers/sdd/2026-09-27-repair-and-engine-master-plan/frozen-source-521fef2/src/engine/eval.ts
var VAL = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 0
};
var PST = {
  p: [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    50,
    50,
    50,
    50,
    50,
    50,
    50,
    50,
    10,
    10,
    20,
    30,
    30,
    20,
    10,
    10,
    5,
    5,
    10,
    25,
    25,
    10,
    5,
    5,
    0,
    0,
    0,
    20,
    20,
    0,
    0,
    0,
    5,
    -5,
    -10,
    0,
    0,
    -10,
    -5,
    5,
    5,
    10,
    10,
    -20,
    -20,
    10,
    10,
    5,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0
  ],
  n: [
    -50,
    -40,
    -30,
    -30,
    -30,
    -30,
    -40,
    -50,
    -40,
    -20,
    0,
    0,
    0,
    0,
    -20,
    -40,
    -30,
    0,
    10,
    15,
    15,
    10,
    0,
    -30,
    -30,
    5,
    15,
    20,
    20,
    15,
    5,
    -30,
    -30,
    0,
    15,
    20,
    20,
    15,
    0,
    -30,
    -30,
    5,
    10,
    15,
    15,
    10,
    5,
    -30,
    -40,
    -20,
    0,
    5,
    5,
    0,
    -20,
    -40,
    -50,
    -40,
    -30,
    -30,
    -30,
    -30,
    -40,
    -50
  ],
  b: [
    -20,
    -10,
    -10,
    -10,
    -10,
    -10,
    -10,
    -20,
    -10,
    0,
    0,
    0,
    0,
    0,
    0,
    -10,
    -10,
    0,
    5,
    10,
    10,
    5,
    0,
    -10,
    -10,
    5,
    5,
    10,
    10,
    5,
    5,
    -10,
    -10,
    0,
    10,
    10,
    10,
    10,
    0,
    -10,
    -10,
    10,
    10,
    10,
    10,
    10,
    10,
    -10,
    -10,
    5,
    0,
    0,
    0,
    0,
    5,
    -10,
    -20,
    -10,
    -10,
    -10,
    -10,
    -10,
    -10,
    -20
  ],
  r: [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    5,
    10,
    10,
    10,
    10,
    10,
    10,
    5,
    -5,
    0,
    0,
    0,
    0,
    0,
    0,
    -5,
    -5,
    0,
    0,
    0,
    0,
    0,
    0,
    -5,
    -5,
    0,
    0,
    0,
    0,
    0,
    0,
    -5,
    -5,
    0,
    0,
    0,
    0,
    0,
    0,
    -5,
    -5,
    0,
    0,
    0,
    0,
    0,
    0,
    -5,
    0,
    0,
    0,
    5,
    5,
    0,
    0,
    0
  ],
  q: [
    -20,
    -10,
    -10,
    -5,
    -5,
    -10,
    -10,
    -20,
    -10,
    0,
    0,
    0,
    0,
    0,
    0,
    -10,
    -10,
    0,
    5,
    5,
    5,
    5,
    0,
    -10,
    -5,
    0,
    5,
    5,
    5,
    5,
    0,
    -5,
    0,
    0,
    5,
    5,
    5,
    5,
    0,
    -5,
    -10,
    5,
    5,
    5,
    5,
    5,
    0,
    -10,
    -10,
    0,
    5,
    0,
    0,
    0,
    0,
    -10,
    -20,
    -10,
    -10,
    -5,
    -5,
    -10,
    -10,
    -20
  ],
  k: [
    -30,
    -40,
    -40,
    -50,
    -50,
    -40,
    -40,
    -30,
    -30,
    -40,
    -40,
    -50,
    -50,
    -40,
    -40,
    -30,
    -30,
    -40,
    -40,
    -50,
    -50,
    -40,
    -40,
    -30,
    -30,
    -40,
    -40,
    -50,
    -50,
    -40,
    -40,
    -30,
    -20,
    -30,
    -30,
    -40,
    -40,
    -30,
    -30,
    -20,
    -10,
    -20,
    -20,
    -20,
    -20,
    -20,
    -20,
    -10,
    20,
    20,
    0,
    0,
    0,
    0,
    20,
    20,
    20,
    30,
    10,
    0,
    0,
    10,
    30,
    20
  ],
  ke: [
    -50,
    -40,
    -30,
    -20,
    -20,
    -30,
    -40,
    -50,
    -30,
    -20,
    -10,
    0,
    0,
    -10,
    -20,
    -30,
    -30,
    -10,
    20,
    30,
    30,
    20,
    -10,
    -30,
    -30,
    -10,
    30,
    40,
    40,
    30,
    -10,
    -30,
    -30,
    -10,
    30,
    40,
    40,
    30,
    -10,
    -30,
    -30,
    -10,
    20,
    30,
    30,
    20,
    -10,
    -30,
    -30,
    -30,
    0,
    0,
    0,
    0,
    -30,
    -30,
    -50,
    -30,
    -30,
    -30,
    -30,
    -30,
    -30,
    -50
  ]
};
var mirror = (square) => (7 - (square >> 3)) * 8 + (square & 7);
function evaluate(position) {
  let score = 0, material = 0, whiteKing = -1, blackKing = -1;
  for (let square = 0; square < 64; square++) {
    const piece = position.board[square];
    if (!piece) continue;
    const type = piece[1];
    if (type === "k") {
      if (piece[0] === "w") whiteKing = square;
      else blackKing = square;
      continue;
    }
    if (type !== "p") material += VAL[type];
    if (piece[0] === "w") score += VAL[type] + PST[type][square];
    else score -= VAL[type] + PST[type][mirror(square)];
  }
  const kingTable = material <= 2600 ? PST.ke : PST.k;
  if (whiteKing >= 0) score += kingTable[whiteKing];
  if (blackKing >= 0) score -= kingTable[mirror(blackKing)];
  return score;
}

// .superpowers/sdd/2026-09-27-repair-and-engine-master-plan/frozen-source-521fef2/src/game/timestamps.ts
var BDT_OFFSET_MS = 6 * 60 * 60 * 1e3;
var MAX_GAME_TIMESTAMP = Date.parse("9999-12-31T17:59:59.999Z");

// .superpowers/sdd/2026-09-27-repair-and-engine-master-plan/frozen-source-521fef2/src/rating/opponents.ts
var MORPHY_RATINGS = Object.freeze({
  casual: 1200,
  club: 1375,
  strong: 1825
});
var HISTORICAL_MORPHY_RATINGS = Object.freeze({
  casual: 1275,
  club: 1375,
  strong: 1775
});
var PLANNED_MORPHY_RATINGS = Object.freeze({
  casual: 1225,
  club: 1400,
  strong: 1625
});
var CHIGORIN_RATINGS = Object.freeze({
  casual: 1250,
  club: 1350,
  strong: 1625
});
var ROSTER_RATINGS = Object.freeze({
  spassky: Object.freeze({ casual: 1150, club: 1325, strong: 1700 }),
  tal: Object.freeze({ casual: 1200, club: 1325, strong: 1700 }),
  fischer: Object.freeze({ casual: 1250, club: 1350, strong: 1675 })
});

// .superpowers/sdd/2026-09-27-repair-and-engine-master-plan/frozen-source-521fef2/src/engine/opponents.ts
var CLASSIC = Object.freeze({
  id: "classic",
  version: 1,
  engine: "classic-v1",
  randomPolicy: "ambient-v1",
  seed: null
});

// .superpowers/sdd/2026-09-27-repair-and-engine-master-plan/frozen-source-521fef2/src/engine/rules-v2.ts
function isDeadPositionV2(board) {
  if (insufficientMaterial(board)) return true;
  let bishopColor;
  for (let square = 0; square < board.length; square++) {
    const piece = board[square];
    if (!piece || piece[1] === "k") continue;
    if (piece[1] !== "b") return false;
    const color = (rowOf(square) + colOf(square)) % 2;
    if (bishopColor !== void 0 && color !== bishopColor) return false;
    bishopColor = color;
  }
  return true;
}

// .superpowers/sdd/2026-09-27-repair-and-engine-master-plan/frozen-source-521fef2/src/engine/next/shortlist-reuse-search.ts
var NEXT_SHORTLIST_REUSE_SEARCH_POLICY = "next-neutral-shortlist-reuse-v1";
var MATE = 1e5;
var Interrupted = class extends Error {
  constructor(reason) {
    super(reason);
    this.reason = reason;
  }
  reason;
};
function historyFingerprint(history) {
  let hash = 0xcbf29ce484222325n;
  for (const character of JSON.stringify(history)) {
    hash ^= BigInt(character.charCodeAt(0));
    hash = BigInt.asUintN(64, hash * 0x100000001b3n);
  }
  return hash.toString(16).padStart(16, "0");
}
function ordered(moves, preferred) {
  const value = (move) => (sameMove(move, preferred) ? 1e5 : 0) + (move.capture ? 10 * VAL[move.capture[1]] : 0) + (move.promo ? VAL[move.promo] : 0);
  return [...moves].sort((a, b) => value(b) - value(a));
}
function searchNextShortlistReuse(position, history, options) {
  if (options.candidateWindowCp !== void 0 && (!Number.isInteger(options.candidateWindowCp) || options.candidateWindowCp < 0 || options.candidateWindowCp > 300) || !Number.isInteger(options.maxDepth) || options.maxDepth < 2 || options.maxDepth > 8 || !Number.isFinite(options.ms) || options.ms < 0 || options.maxNodes !== void 0 && (!Number.isSafeInteger(options.maxNodes) || options.maxNodes < 0) || options.absoluteDeadline !== void 0 && !Number.isFinite(options.absoluteDeadline) || options.forcingSafetyPlies !== void 0 && (!Number.isInteger(options.forcingSafetyPlies) || options.forcingSafetyPlies < 0 || options.forcingSafetyPlies > 12) || !Array.isArray(history) || history.length > 12800)
    throw new Error("Invalid next-search limits or history.");
  const metric = { entry: performance.now(), historyLength: history.length, ms: options.ms, baselineOnly: options.baselineOnly === true };
  globalThis.__probe.push(metric);
  const clock = options.now ?? (() => performance.now());
  const now = () => {
    const value = clock();
    if (!Number.isFinite(value)) throw new Error("Invalid search clock.");
    return value;
  };
  const candidateWindowCp = options.candidateWindowCp ?? 100;
  const safetyPlies = options.forcingSafetyPlies ?? 12;
  const started = now();
  const deadline = Math.min(started + options.ms, options.absoluteDeadline ?? Infinity);
  const counts = /* @__PURE__ */ new Map();
  for (const fen of history) {
    if (typeof fen !== "string" || fen.length > 128) throw new Error("Invalid prior position.");
    const key = posKey(fromFEN(fen));
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  const rootKey = posKey(position);
  counts.set(rootKey, (counts.get(rootKey) ?? 0) + 1);
  let nodes = 0;
  let attemptedDepth = 0;
  let interruption = null;
  const iterations = [];
  const identity = {
    policy: NEXT_SHORTLIST_REUSE_SEARCH_POLICY,
    position: toFEN(position),
    history: historyFingerprint(history),
    perspective: "white"
  };
  const checkpoint = () => {
    if (options.cancelled?.()) throw new Interrupted("cancelled");
    if (now() >= deadline) throw new Interrupted("deadline");
  };
  const enter = () => {
    checkpoint();
    if (nodes >= (options.maxNodes ?? Infinity)) throw new Interrupted("nodes");
    nodes++;
  };
  const terminal = (p, moves2, ply) => {
    if (!moves2.length)
      return inCheck(p, p.turn) ? { score: -MATE + ply, reason: "checkmate" } : { score: 0, reason: "stalemate" };
    if (p.halfmove >= 100) return { score: 0, reason: "fifty-move-rule" };
    if ((counts.get(posKey(p)) ?? 0) >= 3) return { score: 0, reason: "threefold-repetition" };
    if (isDeadPositionV2(p.board)) return { score: 0, reason: "dead-position" };
    return null;
  };
  const child = (p, move, visit) => {
    checkpoint();
    const next = applyMove(p, move), key = posKey(next), previous = counts.get(key) ?? 0;
    counts.set(key, previous + 1);
    try {
      return visit(next);
    } finally {
      if (previous) counts.set(key, previous);
      else counts.delete(key);
    }
  };
  const leaf = (p) => {
    checkpoint();
    const score = evaluate(p) * (p.turn === "w" ? 1 : -1);
    checkpoint();
    if (!Number.isFinite(score)) throw new Error("Non-finite evaluation.");
    return score;
  };
  function baseline(p, remaining, ply) {
    enter();
    const moves2 = legalMoves(p), ending2 = terminal(p, moves2, ply);
    checkpoint();
    if (ending2) return ending2.score;
    if (!remaining) return leaf(p);
    let best = -Infinity;
    for (const move of ordered(moves2))
      best = Math.max(best, -child(p, move, (next) => baseline(next, remaining - 1, ply + 1)));
    return best;
  }
  function forcing(p, alpha, beta, remaining, ply, safety) {
    enter();
    const moves2 = legalMoves(p), ending2 = terminal(p, moves2, ply);
    checkpoint();
    if (ending2) return ending2.score;
    const checked = inCheck(p, p.turn);
    if (checked && safety <= 0) throw new Interrupted("forcing-limit");
    let best = checked ? -Infinity : leaf(p);
    if (!checked) {
      if (best >= beta || remaining <= 0 || safety <= 0) return best;
      alpha = Math.max(alpha, best);
    }
    for (const move of ordered(
      checked ? moves2 : moves2.filter((move2) => move2.capture || move2.promo)
    )) {
      const score = -child(
        p,
        move,
        (next) => forcing(next, -beta, -alpha, remaining - 1, ply + 1, safety - 1)
      );
      best = Math.max(best, score);
      alpha = Math.max(alpha, score);
      if (alpha >= beta) break;
    }
    return best;
  }
  function negamax(p, depth, alpha, beta, ply) {
    if (depth <= 0) return forcing(p, alpha, beta, 4, ply, safetyPlies);
    enter();
    const moves2 = legalMoves(p), ending2 = terminal(p, moves2, ply);
    checkpoint();
    if (ending2) return ending2.score;
    let best = -Infinity;
    for (const move of ordered(moves2)) {
      const score = -child(p, move, (next) => negamax(next, depth - 1, -beta, -alpha, ply + 1));
      best = Math.max(best, score);
      alpha = Math.max(alpha, score);
      if (alpha >= beta) break;
    }
    return best;
  }
  const moves = legalMoves(position), ending = terminal(position, moves, 0);
  metric.prepared = performance.now();
  const evidence = () => ({
    ...identity,
    nodes,
    elapsedMs: Math.max(0, now() - started),
    attemptedDepth,
    interruption,
    terminal: ending?.reason ?? null,
    iterations,
    settings: {
      candidateWindowCp,
      maxDepth: options.maxDepth,
      forcingCapturePlies: 4,
      forcingSafetyPlies: safetyPlies,
      baselineOnly: options.baselineOnly === true
    }
  });
  const sign = position.turn === "w" ? 1 : -1;
  if (ending)
    return {
      ...evidence(),
      kind: "terminal",
      move: null,
      score: ending.score === 0 ? 0 : ending.score * sign,
      depth: 0,
      phase: null,
      candidates: []
    };
  let snapshot = null;
  const iteration = (depth, phase) => {
    attemptedDepth = depth;
    const candidates = [];
    let bestRelative = -Infinity;
    for (const move of ordered(moves, snapshot?.move)) {
      checkpoint();
      if (phase === "forcing" && Number.isFinite(bestRelative)) {
        const threshold = bestRelative - candidateWindowCp;
        const bound = -child(
          position,
          move,
          (next) => negamax(next, depth - 1, -Infinity, -threshold, 1)
        );
        if (bound < threshold) {
          candidates.push({
            move,
            score: bound === 0 ? 0 : bound * sign,
            kind: sign === 1 ? "upper-bound" : "lower-bound",
            depth
          });
          continue;
        }
        if (bound > threshold) {
          bestRelative = Math.max(bestRelative, bound);
          candidates.push({ move, score: bound === 0 ? 0 : bound * sign, kind: "exact", depth });
          continue;
        }
      }
      const score = -child(
        position,
        move,
        (next) => phase === "baseline" ? baseline(next, 1, 1) : negamax(next, depth - 1, -Infinity, Infinity, 1)
      );
      bestRelative = Math.max(bestRelative, score);
      candidates.push({ move, score: score === 0 ? 0 : score * sign, kind: "exact", depth });
    }
    checkpoint();
    const best = candidates.filter((candidate) => candidate.kind === "exact").reduce((a, b) => b.score * sign > a.score * sign ? b : a);
    snapshot = { move: best.move, score: best.score, depth, phase, candidates };
    iterations.push({ phase, depth, nodes });
  };
  try {
    metric.baselineStart = performance.now();
    iteration(2, "baseline");
    metric.baselineEnd = performance.now();
    if (!options.baselineOnly)
      for (let depth = 2; depth <= options.maxDepth; depth++) iteration(depth, "forcing");
  } catch (error) {
    if (!(error instanceof Interrupted)) throw error;
    interruption = error.reason;
  }
  const completed = snapshot;
  metric.returned = performance.now();
  return completed ? { ...evidence(), kind: "completed", ...completed } : {
    ...evidence(),
    kind: "incomplete",
    move: null,
    score: null,
    depth: 0,
    phase: null,
    candidates: []
  };
}

// <stdin>
self.onmessage = ({ data: r }) => self.postMessage({ ok: true, requestId: r.requestId, gameId: r.gameId, revision: r.revision, result: searchNextShortlistReuse(r.position, r.history, { maxDepth: 2, ms: 1, now: () => 0, maxNodes: 1e6, baselineOnly: true }) });
