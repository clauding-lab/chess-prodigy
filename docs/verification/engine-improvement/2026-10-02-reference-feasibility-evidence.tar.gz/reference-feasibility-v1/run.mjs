// Evidence-only development feasibility harness. No product imports this file.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import {pathToFileURL} from 'node:url';
import {Worker} from 'node:worker_threads';
import {buildSync} from 'esbuild';
const root=process.cwd(),base=path.join(root,'.superpowers/sdd/2026-09-27-repair-and-engine-master-plan'),frozen=path.join(base,'frozen-source-521fef2'),out=path.join(base,'reference-feasibility-v1');
const hash=v=>crypto.createHash('sha256').update(v).digest('hex'),read=p=>fs.readFileSync(p,'utf8'),json=p=>JSON.parse(read(p));
const write=(name,v)=>fs.writeFileSync(path.join(out,name),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const original=json(path.join(base,'strength-development-v1/fischer-casual/manifest.json'));
if(process.version!==original.machine.node)throw Error('Node drift');
for(const [p,h] of Object.entries(original.source))if(hash(fs.readFileSync(path.join(frozen,p)))!==h)throw Error('Source drift '+p);
const {START,applyMove,legalMoves,sanFor,toFEN}=await import(pathToFileURL(path.join(frozen,'src/engine/board.ts')));
const {nextHistoryIdentity}=await import(pathToFileURL(path.join(frozen,'src/worker/next/protocol.ts')));
const dir=path.join(root,'docs/verification/engine-improvement'),raw=read(path.join(dir,'e0-dataset-v1/development.json')),dm=json(path.join(dir,'e0-dataset-v1/manifest.json')),cohort=json(path.join(dir,'e0-development12-production-isolated-v1/run-manifest.json'));
if(hash(raw)!==dm.partitions.development||hash(raw)!==cohort.developmentHash||hash(JSON.stringify(dm))!==cohort.datasetManifestHash||cohort.samples.length!==12||new Set(cohort.samples).size!==12)throw Error('Dataset drift');
const data=JSON.parse(raw);
const inputs=cohort.samples.map(id=>{
 const s=data.find(s=>s.id===id&&s.split==='development');if(!s)throw Error('Missing development input');
 let position=START();const history=[];
 for(const san of s.history){history.push(toFEN(position));const move=legalMoves(position).find(m=>sanFor(position,m,applyMove(position,m))===san);if(!move)throw Error('Illegal history');position=applyMove(position,move);}
 if(toFEN(position)!==s.fen)throw Error('Wrong FEN');return {id,position,history};
});
const bundle=buildSync({stdin:{contents:`import {searchNext} from './src/engine/next/search';const {parentPort}=require('node:worker_threads');parentPort.on('message',r=>{try{parentPort.postMessage({key:r.key,result:searchNext(r.position,r.history,{maxDepth:r.depth,ms:1,now:()=>0,maxNodes:10000000,forcingSafetyPlies:12})});}catch(e){parentPort.postMessage({key:r.key,error:String(e)});}});parentPort.postMessage({ready:true});`,resolveDir:frozen},bundle:true,write:false,format:'cjs',platform:'node'}).outputFiles[0].text;
fs.writeFileSync(path.join(out,'reference.cjs'),bundle,{flag:'wx'});
const schedule=inputs.flatMap((input,index)=>[3,4].map(depth=>({key:`${String(index+1).padStart(2,'0')}-depth${depth}`,depth,...input})));
write('manifest.json',{purpose:'development-reference-feasibility-only',qualification:false,node:process.version,machine:{cpu:os.cpus()[0].model,arch:os.arch(),platform:os.platform()},source:original.source,runnerHash:hash(read(new URL(import.meta.url))),bundleHash:hash(bundle),datasetHash:hash(raw),protocolHash:hash(read('docs/superpowers/specs/2026-10-02-reference-feasibility.md')),settings:{maxNodes:10000000,clock:'constant-zero',forcingCapturePlies:4,forcingSafetyPlies:12,capacityMs:120000},schedule});
const summaries=[];
for(const request of schedule){
 write(request.key+'.started.json',{key:request.key,startedAt:new Date().toISOString()});
 const start=performance.now();let ready=null,end=null,response=null,record;
 const worker=new Worker(bundle,{eval:true});
 try{
 response=await new Promise((resolve,reject)=>{
 const timer=setTimeout(()=>reject(Error('Feasibility resource cap')),120000),settle=(f,v)=>{clearTimeout(timer);f(v);};
 worker.once('error',e=>settle(reject,e));worker.once('exit',c=>settle(reject,Error('Worker exited '+c)));
 worker.on('message',m=>{if(m.ready===true&&ready===null){ready=performance.now();worker.postMessage(request);}else if(Object.hasOwn(m,'key')){end=performance.now();settle(resolve,m);}});
 });
 const r=response.result,legal=legalMoves(request.position),key=m=>JSON.stringify([m.from,m.to,m.promo,m.capture,m.ep,m.double,m.castle]);
 if(response.key!==request.key||response.error||!r)throw Error(response.error??'Invalid reply');
 const complete=r.kind==='completed'&&r.phase==='forcing'&&r.depth===request.depth&&r.interruption===null;
 const valid=r.position===toFEN(request.position)&&r.history===nextHistoryIdentity(request.history)&&r.policy==='next-neutral-v1'&&r.perspective==='white'&&r.nodes<=10000000&&r.settings.maxDepth===request.depth&&r.settings.forcingCapturePlies===4&&r.settings.forcingSafetyPlies===12;
 if(!valid)throw Error('Invalid reference identity/settings');
 if(complete){
 if(r.candidates.length!==legal.length||new Set(r.candidates.map(c=>key(c.move))).size!==legal.length||!r.candidates.every(c=>c.kind==='exact'&&c.depth===request.depth&&Number.isFinite(c.score)&&legal.some(m=>key(m)===key(c.move))))throw Error('Incomplete exact root coverage');
 const sign=request.position.turn==='w'?1:-1,best=Math.max(...r.candidates.map(c=>c.score*sign));
 if(r.score*sign!==best||!r.candidates.some(c=>key(c.move)===key(r.move)&&c.score===r.score))throw Error('Best result mismatch');
 }
 record={request,response,complete,startupMs:ready-start,calculationMs:end-ready,elapsedMs:end-start};
 }catch(e){record={request,response,complete:false,error:String(e),startupMs:ready===null?null:ready-start,calculationMs:ready===null?null:(end??performance.now())-ready,elapsedMs:performance.now()-start};}
 finally{await worker.terminate();}
 write(request.key+'.json',record);const summary={key:request.key,complete:record.complete,error:record.error??null,nodes:response?.result?.nodes,depth:response?.result?.depth,interruption:response?.result?.interruption,calculationMs:record.calculationMs};summaries.push(summary);console.log(JSON.stringify(summary));
}
write('summary.json',{qualification:false,total:24,complete:summaries.filter(r=>r.complete).length,rows:summaries});
