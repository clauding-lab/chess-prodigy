// Evidence-only development rehearsal. No validation reader or product entry point.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import os from 'node:os';import {pathToFileURL} from 'node:url';
const root=process.cwd(),base=path.join(root,'.superpowers/sdd/2026-09-27-repair-and-engine-master-plan'),out=path.join(base,'tactical-rehearsal-v1'),refDir=path.join(base,'reference-feasibility-v1');
const hash=v=>crypto.createHash('sha256').update(v).digest('hex'),read=p=>fs.readFileSync(p),json=p=>JSON.parse(read(p));
if(fs.existsSync(out))throw Error('Existing rehearsal: no restart');
const load=p=>import(pathToFileURL(path.join(root,p)));
const {START,applyMove,legalMoves,sanFor,toFEN}=await load('src/engine/board.ts');
const {nextHistoryIdentity}=await load('src/worker/next/protocol.ts');
const {workerChooser}=await load('scripts/engine-bench/strength-worker.ts');
const {sharedTacticalFailure}=await load('scripts/engine-bench/tactical-protocol.ts');
const originalDir=path.join(base,'strength-development-v1/fischer-casual'),original=json(path.join(originalDir,'manifest.json'));
const machine={node:process.version,arch:os.arch(),platform:os.platform(),cpu:os.cpus()[0].model,cpuCount:os.cpus().length};
if(JSON.stringify(machine)!==JSON.stringify(original.machine))throw Error('Machine mismatch');
const bundles={};for(const name of ['experiment','tal','fischer']){const b=read(path.join(originalDir,name+'.cjs'));if(hash(b)!==original.bundles[name])throw Error('Worker drift');bundles[name]=b.toString();}
const dm=json('docs/verification/engine-improvement/e0-dataset-v1/manifest.json'),cohort=json('docs/verification/engine-improvement/e0-development12-production-isolated-v1/run-manifest.json'),raw=read('docs/verification/engine-improvement/e0-dataset-v1/development.json');
if(hash(raw)!==cohort.developmentHash||hash(raw)!==dm.partitions.development||hash(JSON.stringify(dm))!==cohort.datasetManifestHash||cohort.samples.length!==12||new Set(cohort.samples).size!==12)throw Error('Dataset drift');
const all=JSON.parse(raw),key=m=>JSON.stringify([m.from,m.to,m.promo,m.capture,m.ep,m.double,m.castle]);
const inputs=cohort.samples.map(id=>{const s=all.find(s=>s.id===id&&s.split==='development');if(!s)throw Error('Missing sample');let position=START();const history=[];for(const san of s.history){history.push(toFEN(position));const m=legalMoves(position).find(m=>sanFor(position,m,applyMove(position,m))===san);if(!m)throw Error('Illegal history');position=applyMove(position,m);}if(toFEN(position)!==s.fen)throw Error('FEN drift');return {id,gameId:s.gameId,position,history,moves:s.history};});
const refManifest=json(path.join(refDir,'manifest.json')),refHashes={};
if(hash(read(path.join(refDir,'reference.cjs')))!==refManifest.bundleHash||hash(read(path.join(refDir,'run.mjs')))!==refManifest.runnerHash||refManifest.schedule.length!==24)throw Error('Reference manifest drift');
for(const [p,h] of Object.entries(refManifest.source))if(hash(read(path.join(base,'frozen-source-521fef2',p)))!==h)throw Error('Reference source drift');
const references=new Map();
for(let i=0;i<inputs.length;i++)for(const depth of [3,4]){
 const input=inputs[i],name=`${String(i+1).padStart(2,'0')}-depth${depth}`,file=path.join(refDir,name+'.json'),record=json(file),r=record.response?.result,legal=legalMoves(input.position),expected={key:name,depth,id:input.id,position:input.position,history:input.history};
 if(JSON.stringify(record.request)!==JSON.stringify(expected)||JSON.stringify(refManifest.schedule[i*2+depth-3])!==JSON.stringify(expected)||!record.complete||record.error||r?.kind!=='completed'||r.depth!==depth||r.phase!=='forcing'||r.interruption!==null||r.policy!=='next-neutral-v1'||r.position!==toFEN(input.position)||r.history!==nextHistoryIdentity(input.history)||r.perspective!=='white'||r.nodes>10000000||r.settings.maxDepth!==depth||r.settings.forcingCapturePlies!==4||r.settings.forcingSafetyPlies!==12||r.settings.baselineOnly!==false)throw Error('Invalid reference '+name);
 if(r.candidates.length!==legal.length||new Set(r.candidates.map(c=>key(c.move))).size!==legal.length||!r.candidates.every(c=>c.kind==='exact'&&c.depth===depth&&Number.isFinite(c.score)&&legal.some(m=>key(m)===key(c.move))))throw Error('Root coverage '+name);
 const sign=input.position.turn==='w'?1:-1;if(r.score*sign!==Math.max(...r.candidates.map(c=>c.score*sign))||!r.candidates.some(c=>key(c.move)===key(r.move)&&c.score===r.score))throw Error('Reference best mismatch');
 refHashes[name+'.json']=hash(read(file));references.set(input.id+':'+depth,r);
}
const schedule=[];for(let i=0;i<inputs.length;i++)for(const [si,seed] of [317,9029].entries())for(const level of ['club','strong'])for(const opponent of ['tal','fischer'])for(const side of (i+si)%2===0?['candidate','baseline']:['baseline','candidate'])schedule.push({key:`${String(i+1).padStart(2,'0')}-${seed}-${level}-${opponent}-${side}`,index:i,sample:inputs[i].id,seed,level,opponent,side});
if(schedule.length!==192||new Set(schedule.map(r=>r.key)).size!==192)throw Error('Schedule coverage');
const files=p=>fs.readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(p,e.name)):[path.join(p,e.name)]);
const protocol='docs/superpowers/specs/2026-10-02-tactical-development-rehearsal.md';
const source=()=>Object.fromEntries([...files('src'),...files('scripts/engine-bench'),'scripts/calibration/core.ts','package.json','package-lock.json',protocol].sort().map(p=>[p,hash(read(p))]));
const frozenSource=source();fs.mkdirSync(out);const write=(n,v)=>fs.writeFileSync(path.join(out,n),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
write('manifest.json',{purpose:'development-tactical-rehearsal-only',qualification:false,machine,source:frozenSource,runnerHash:hash(read(new URL(import.meta.url))),bundles:original.bundles,referenceManifestHash:hash(read(path.join(refDir,'manifest.json'))),referenceHashes:refHashes,datasetHash:hash(raw),inputs,schedule});
const records=[];
for(const item of schedule){
 if(JSON.stringify(source())!==JSON.stringify(frozenSource))throw Error('Source drift');
 write(item.key+'.started.json',{key:item.key,startedAt:new Date().toISOString()});
 const input=inputs[item.index],row={key:item.key,candidate:item.opponent,baseline:item.opponent,level:item.level,pair:0,color:input.position.turn,seed:item.seed,baselineSeed:item.seed};
 let record;
 try{const decision=await workerChooser(row,bundles)(input.position,input.history,input.moves,item.side==='candidate');if(!legalMoves(input.position).some(m=>key(m)===key(decision.move)))throw Error('Illegal selected move');record={item,row,decision,error:null};}
 catch(e){record={item,row,decision:null,error:String(e),failureEvidence:e.evidence??null};}
 write(item.key+'.json',record);records.push(record);console.log(JSON.stringify({key:item.key,complete:record.error===null,error:record.error}));
}
if(JSON.stringify(source())!==JSON.stringify(frozenSource))throw Error('Source drift after schedule');
const counts=[];
if(records.every(r=>r.error===null))for(const opponent of ['tal','fischer'])for(const level of ['club','strong']){
 const countsRow={opponent,level,decisionsPerSide:24,candidateFailures:0,baselineFailures:0};
 for(const side of ['candidate','baseline']){
 const rows=records.filter(r=>r.item.opponent===opponent&&r.item.level===level&&r.item.side===side);if(rows.length!==24)throw Error('Missing denominator');
 for(const row of rows){const input=inputs[row.item.index],sign=input.position.turn==='w'?1:-1,pairs=[3,4].map(d=>{const r=references.get(input.id+':'+d),selected=r.candidates.find(c=>key(c.move)===key(row.decision.move));if(!selected)throw Error('Missing selected reference');return [r.score*sign,selected.score*sign];});if(sharedTacticalFailure(pairs[0],pairs[1]))countsRow[side+'Failures']++;}
 }counts.push(countsRow);
}
write('summary.json',{purpose:'development-tactical-rehearsal-only',qualification:false,scheduled:192,complete:records.filter(r=>r.error===null).length,classificationComplete:records.every(r=>r.error===null),counts,statement:'Development reference-defined failure counts only; no tactical qualification or strength claim.'});
